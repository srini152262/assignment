INSERT INTO author(author_id, name, age) values (1, 'srini', 35);
INSERT INTO author(author_id, name, age) values (2, 'meera', 30);
INSERT INTO author(author_id, name, age) values (3, 'prithivi', 21);
INSERT INTO book(book_id, book_name, content, author_id) values (1, 'Box Car 1', 'First content writing', 1);
INSERT INTO book(book_id, book_name, content, author_id) values (2, 'Box Car 2', 'Second writing content', 1);
INSERT INTO book(book_id, book_name, content, author_id) values (3, 'Box Car 3', ' writing Third writing content writing writing', 1);
INSERT INTO book(book_id, book_name, content, author_id) values (4, 'Box Car 4', 'Fourth content', 2);
INSERT INTO book(book_id, book_name, content, author_id) values (5, 'Box Car 5', 'Writing Fifth content writing', 2);
INSERT INTO book(book_id, book_name, content, author_id) values (6, 'Box Car 5', 'Writing Sixth Writing content writing', 2);
