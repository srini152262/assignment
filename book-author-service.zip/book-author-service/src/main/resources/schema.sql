DROP TABLE IF EXISTS book;

DROP TABLE IF EXISTS author;

CREATE TABLE author
(
    author_id BIGINT auto_increment NOT NULL,
    name VARCHAR(255) NOT NULL,
    age INT NOT NULL,
    PRIMARY KEY(author_id)
);

CREATE TABLE book
(
    book_id BIGINT auto_increment NOT NULL,
    book_name VARCHAR(255) NOT NULL,
    content CLOB NOT NULL,
    author_id BIGINT NOT NULL,
    PRIMARY KEY(book_id),
    FOREIGN KEY (author_id) REFERENCES author
);