package com.cisco.assignment.dto;

import com.cisco.assignment.model.Book;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.modelmapper.ModelMapper;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

@Getter
@Setter
public class BookRequestDTO {

    @Schema(description = "Unique identifier of the Book.",
            example = "1", required = true)
    @JsonIgnore
    private long bookId;

    @Schema(description = "Name of the book",
            example = "Box Cars", required = true)
    @JsonProperty(value = "bookName")
    @NotBlank(message = "Book Name cannot be blank")
    private String bookName;

    @Schema(description = "Content of the book",
            example = "This guides you on how to develop rest api in spring boot application", required = true)
    @JsonProperty(value = "content")
    @NotBlank(message = "Book Content cannot be blank")
    private String content;

    @Schema(description = "Author of the book",
            required = true)
    @JsonIgnore
    private AuthorDTO author;

    public Book convertToEntity() {
        ModelMapper mapper = new ModelMapper();
        return mapper.map(this, Book.class);
    }
}
