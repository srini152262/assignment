package com.cisco.assignment.repository;

import com.cisco.assignment.dto.AuthorDTO;
import com.cisco.assignment.model.Author;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface AuthorRepository extends JpaRepository<Author, Long> {

    /**
     * Find list of author by name
     *
     * @param name Name of the author
     * @return List Of {@link Author}
     */
    List<Author> findByNameIgnoreCase(String name);

    /**
     * Find list of author
     *
     * @param name Name of the author
     * @param age  Age
     * @return List of {@link Author}
     */
    List<Author> findByNameIgnoreCaseAndAge(String name, Integer age);

    /**
     * Get top N authors who used the word most
     *
     * @param word Search Word
     * @param limit Limit of the search
     * @return List Of {@link AuthorDTO}
     */
    @Query(value = "SELECT * FROM (SELECT distinct author.*,ROUND((LENGTH(LOWER(content)) - LENGTH(REPLACE(LOWER(content), LOWER(:word), '')))/LENGTH(LOWER(:word))) AS word_cnt FROM book, author WHERE book.author_id=author.author_id) WHERE word_cnt > 0 ORDER BY word_cnt DESC LIMIT :limit", nativeQuery = true)
    Set<Author> findAuthorsWhoUsesGivenWordMost(@Param("word") String word, @Param("limit") Integer limit);

    /**
     * Get top N authors who used the word least or not
     *
     * @param word Search Word
     * @param limit Limit of the search
     * @return List Of {@link AuthorDTO}
     */
    @Query(value = "SELECT * FROM(SELECT * FROM (SELECT author.*,ROUND((LENGTH(LOWER(content)) - LENGTH(REPLACE(LOWER(content), LOWER(:word), '')))/LENGTH(LOWER(:word))) AS word_cnt FROM book, author where book.author_id=author.author_id) WHERE word_cnt > 0\n" +
            "UNION\n" +
            "SELECT author.*,ROUND((LENGTH(LOWER(content)) - LENGTH(REPLACE(LOWER(content), LOWER(:word), '')))/LENGTH(LOWER(:word))) AS word_cnt FROM book, author where book.author_id=author.author_id  and LOWER(content) NOT LIKE LOWER('%:word%')) t ORDER BY word_cnt ASC LIMIT :limit", nativeQuery = true)
    Set<Author> findAuthorsWhoUsesGivenWordLeastOrNot(@Param("word") String word, @Param("limit") Integer limit);
}
