package com.cisco.assignment.service;

import com.cisco.assignment.dto.AuthorDTO;
import com.cisco.assignment.dto.AuthorRequestDTO;
import com.cisco.assignment.dto.AuthorUpdateDTO;
import com.cisco.assignment.exception.ResourceAlreadyFoundException;
import com.cisco.assignment.exception.ResourceNotFoundException;
import com.cisco.assignment.model.Author;
import com.cisco.assignment.repository.AuthorRepository;
import com.cisco.assignment.repository.BookRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

@Service
public class AuthorService {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthorService.class);

    @Autowired
    private AuthorRepository authorRepository;

    @Autowired
    private BookRepository bookRepository;

    public AuthorService(AuthorRepository authorRepository) {
        this.authorRepository = authorRepository;
    }

    /**
     * Get All Authors
     *
     * @return List Of {@link AuthorDTO}
     */
    public Optional<List<AuthorDTO>> getAllAuthors() {
        List<AuthorDTO> authorDTOList = new ArrayList<>();
        authorRepository.findAll().stream().forEach(author -> {
            authorDTOList.add(author.convertToDTO());
        });
        if (authorDTOList.size() > 0) {
            return Optional.of(authorDTOList);
        } else {
            throw new ResourceNotFoundException("No Authors Found");
        }
    }

    /**
     * Get Author By Name
     *
     * @param authorName Name of the author
     * @return Optional Of {@link AuthorDTO}
     */
    public List<AuthorDTO> getAuthorByName(String authorName) {
        List<AuthorDTO> authorDTOList = new ArrayList<>();
        List<Author> authorList = authorRepository.findByNameIgnoreCase(authorName);
        if (Objects.nonNull(authorList) && authorList.size() > 0) {
            authorList.stream().forEach(author -> {
                authorDTOList.add(author.convertToDTO());
            });
        } else {
            throw new ResourceNotFoundException("No Authors Found with the name " + authorName);
        }
        return authorDTOList;
    }

    /**
     * Create new author
     *
     * @param authorRequestDTO {@link AuthorRequestDTO}
     * @return AuthorDTO
     */
    public Optional<AuthorDTO> createAuthor(AuthorRequestDTO authorRequestDTO) {
        List<Author> byFirstNameAndLastName = authorRepository.findByNameIgnoreCaseAndAge(
                authorRequestDTO.getName(),
                authorRequestDTO.getAge());
        AtomicBoolean proceed = new AtomicBoolean(true);
        byFirstNameAndLastName.stream()
                .forEach(author -> {
                    if (author.equals(authorRequestDTO.convertToEntity())) {
                        proceed.set(false);
                        return;
                    }
                });
        if (proceed.get()) {
            return Optional.of(authorRepository.save(authorRequestDTO.convertToEntity()).convertToDTO());
        } else {
            throw new ResourceAlreadyFoundException("Author Already Exists");
        }
    }

    /**
     * Update Author By Name
     *
     * @param name            Name of the author
     * @param authorUpdateDTO {@link AuthorUpdateDTO}
     * @return AuthorDTO
     */
    public Optional<AuthorDTO> updateAuthorByName(
            String name,
            AuthorUpdateDTO authorUpdateDTO) {
        List<Author> authorList = authorRepository.findByNameIgnoreCase(name);
        if (Objects.nonNull(authorList) && authorList.size() > 0) {
            authorList.get(0).setAge(authorUpdateDTO.getAge());
            return Optional.of(authorRepository.save(authorList.get(0)).convertToDTO());
        } else {
            throw new ResourceNotFoundException("No Authors Found with the name " + name);
        }
    }

    /**
     * Get top ten authors who used the word most
     *
     * @param word Search Word
     * @param limit Limit of the search
     * @return List Of {@link AuthorDTO}
     */
    public List<AuthorDTO> getAuthorsWhoUsedGivenWordMost(String word, Integer limit) {
        List<AuthorDTO> authorDTOList = new ArrayList<>();
        Set<Author> topTenAuthorsWhoUsesGivenWordMost = authorRepository.findAuthorsWhoUsesGivenWordMost(word, limit);
        if (Objects.nonNull(topTenAuthorsWhoUsesGivenWordMost) && topTenAuthorsWhoUsesGivenWordMost.size() > 0) {
            topTenAuthorsWhoUsesGivenWordMost.stream().forEach(author -> {
                authorDTOList.add(author.convertToDTO());
            });
        } else {
            throw new ResourceNotFoundException("No Authors found for the given word " + word);
        }
        return authorDTOList;
    }

    /**
     * Get top ten authors who used the word least or not
     *
     * @param word Search Word
     * @param limit Limit of the search
     * @return List Of {@link AuthorDTO}
     */
    public List<AuthorDTO> getAuthorsWhoUsedGivenWordLeastOrNot(String word, Integer limit) {
        List<AuthorDTO> authorDTOList = new ArrayList<>();
        Set<Author> topTenAuthorsWhoUsesGivenWordMost = authorRepository.findAuthorsWhoUsesGivenWordLeastOrNot(word, limit);
        if (Objects.nonNull(topTenAuthorsWhoUsesGivenWordMost) && topTenAuthorsWhoUsesGivenWordMost.size() > 0) {
            topTenAuthorsWhoUsesGivenWordMost.stream().forEach(author -> {
                authorDTOList.add(author.convertToDTO());
            });
        } else {
            throw new ResourceNotFoundException("No Authors found who doesn't or least use  the given word " + word);
        }
        return authorDTOList;
    }

    /**
     * Delete author by name
     *
     * @param authorName Name of the author
     * @return Boolean
     */
    public Optional<Boolean> deleteAuthorByName(String authorName) {
        List<Author> authorList = authorRepository.findByNameIgnoreCase(authorName);
        if (Objects.nonNull(authorList) && authorList.size() > 0) {
            authorRepository.deleteAll(authorList);
        } else {
            throw new ResourceNotFoundException("No Authors Found with the name " + authorName);
        }
        return Optional.of(true);
    }

}
