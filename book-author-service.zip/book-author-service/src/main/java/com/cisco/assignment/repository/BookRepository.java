package com.cisco.assignment.repository;

import com.cisco.assignment.dto.BookDTO;
import com.cisco.assignment.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    /**
     * Find Author
     *
     * @param authorId Author ID
     * @return List Of {@link Book}
     */
    List<Book> findByAuthorAuthorId(Long authorId);

    /**
     * Find Book by Book Name and Author Name
     *
     * @param bookName   Name of the book
     * @param authorName name of the author
     * @return Book
     */
    @Query(value = "SELECT book.* FROM book,author where book.author_id=author.author_id and lower(book.book_name)=lower(:bookName) and lower(author.name)=lower(:authorName)", nativeQuery = true)
    Book findByBookNameAndAuthorName(String bookName, String authorName);

    /**
     * Retrieve Top N books in which the given word is used a lot
     *
     * @param word  Search Word
     * @param limit Limit the results
     * @return List Of {@link BookDTO}
     */
    @Query(value = "SELECT * FROM (SELECT *,ROUND((LENGTH(LOWER(content)) - LENGTH(REPLACE(LOWER(content), LOWER(:word), '')))/LENGTH(LOWER(:word))) AS word_cnt FROM book) WHERE word_cnt > 0 ORDER BY word_cnt DESC LIMIT :limit", nativeQuery = true)
    Set<Book> findBooksWhichUsesGivenWordMost(@Param("word") String word, @Param("limit") Integer limit);

    /**
     * Retrieve Top N books in which a given word is not used at all or used least number of times
     *
     * @param word  Search Word
     * @param limit Limit the results
     * @return List Of {@link BookDTO}
     */
    @Query(value = "SELECT * FROM(SELECT * FROM (SELECT *,ROUND((LENGTH(LOWER(content)) - LENGTH(REPLACE(LOWER(content), LOWER(:word), '')))/LENGTH(LOWER(:word))) AS word_cnt FROM book) WHERE word_cnt > 0\n" +
            "UNION\n" +
            "SELECT *,ROUND((LENGTH(LOWER(content)) - LENGTH(REPLACE(LOWER(content), LOWER(:word), '')))/LENGTH(LOWER(:word))) AS word_cnt FROM book where LOWER(content) NOT LIKE LOWER('%:word%')) t ORDER BY word_cnt ASC LIMIT :limit", nativeQuery = true)
    Set<Book> findBooksNotUsedOrLeastUsedByGivenWord(@Param("word") String word, @Param("limit") Integer limit);

}


