package com.cisco.assignment.controller;

import com.cisco.assignment.dto.AuthorDTO;
import com.cisco.assignment.dto.BookDTO;
import com.cisco.assignment.dto.BookRequestDTO;
import com.cisco.assignment.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import java.util.List;
import java.util.Optional;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@Validated
@Tag(name = "books", description = "The Books API")
@RequestMapping(path = {"/api/v1"}, produces = APPLICATION_JSON_VALUE)
public class BookController {

    @Autowired
    private BookService bookService;

    /**
     * Create New Book
     *
     * @param authorName     Name of the Author
     * @param bookRequestDTO {@link BookRequestDTO}
     * @return BookDTO
     */
    @Operation(summary = "Create new book", tags = "books")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Created new book",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid input supplied",
                    content = @Content)})
    @PostMapping("/authors/{authorName}/books")
    public ResponseEntity<BookDTO> createBooks(
            @Parameter(name = "authorName", description = "Name of the author", required = true)
            @PathVariable(value = "authorName") @NotBlank(message = "Name cannot be blank") String authorName,
            @Valid @RequestBody BookRequestDTO bookRequestDTO) {
        Optional<BookDTO> bookDTOOptional = bookService.createBook(authorName, bookRequestDTO);
        if (bookDTOOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.CREATED).body(bookDTOOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    /**
     * Update the content of the book
     *
     * @param authorName Name of the author
     * @param bookName   Name of the book
     * @param content    Content of the book
     * @return BookDTO
     */
    @Operation(summary = "Update content of a book", tags = "books")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Updated the content of a book",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = BookDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid input supplied",
                    content = @Content)})
    @PutMapping("/authors/{authorName}/books/{bookName}")
    public ResponseEntity<BookDTO> updateContentOfBook(
            @Parameter(name = "authorName", description = "Name of the author", required = true)
            @PathVariable(value = "authorName") @NotBlank(message = "Name of the author cannot be blank") String authorName,
            @Parameter(name = "bookName", description = "Name of the book", required = true)
            @PathVariable(value = "bookName") @NotBlank(message = "Name of the book cannot be blank") String bookName,
            @Valid @RequestBody String content
    ) {
        Optional<BookDTO> bookDTOOptional = bookService.updateBookContent(authorName, bookName, content);
        if (bookDTOOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).body(bookDTOOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    /**
     * Get all the books
     *
     * @param authorName Name of the author
     * @return List Of {@link BookDTO}
     */
    @Operation(summary = "Get all the books by name of the author", tags = "books")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found all the books for the given name of the author",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid input supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "Books not found",
                    content = @Content)})
    @GetMapping("/authors/{authorName}/books")
    public ResponseEntity<List<BookDTO>> getAllBooksByAuthorName(
            @Parameter(name = "authorName", description = "Name of the author", required = true)
            @PathVariable(value = "authorName") @NotBlank(message = "Name of the author cannot be blank") String authorName) {
        Optional<List<BookDTO>> allBooksByAuthorNameOptional = bookService.getAllBooksByAuthorName(authorName);
        if (allBooksByAuthorNameOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).body(allBooksByAuthorNameOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Retrieve Top N books in which the given word is used a lot
     *
     * @param word  Search Word
     * @param limit Limit the results
     * @return List Of {@link BookDTO}
     */
    @Operation(summary = "Retrieve Top N books in which the given word is used a lot", tags = "books")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Retrieve Top N books in which the given word is used a lot",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid id supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "No Books found for the given word",
                    content = @Content)})
    @GetMapping("/books/mostused/word/{word}/limit/{limit}")
    public ResponseEntity<List<BookDTO>> getBooksWhichUseGivenWordTheMost(
            @Parameter(description = "Word to search", required = true)
            @PathVariable(value = "word") @NotBlank(message = "Search word cannot be blank") String word,
            @Parameter(description = "Limit the results", required = true)
            @PathVariable(value = "limit") @Min(1) Integer limit) {
        Optional<List<BookDTO>> allBooksByAuthorIdOptional = Optional.ofNullable(bookService.getBooksWhichUsesGivenWordMost(word, limit));
        if (allBooksByAuthorIdOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).body(allBooksByAuthorIdOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Retrieve Top N books in which a given word is not used at all or used least number of times
     *
     * @param word  Search Word
     * @param limit Limit the results
     * @return List Of {@link BookDTO}
     */
    @Operation(summary = "Retrieve Top N books in which a given word is not used at all or used least number of times", tags = "books")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Retrieve Top N books in which a given word is not used at all or used least number of\n" +
                    "times",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid id supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "No Books found for the given word",
                    content = @Content)})
    @GetMapping("/books/leastused/word/{word}/limit/{limit}")
    public ResponseEntity<List<BookDTO>> getBooksNotUsedOrLeastUsedByGivenWord(
            @Parameter(description = "Word to search", required = true)
            @PathVariable(value = "word") @NotBlank(message = "Search word cannot be blank") String word,
            @Parameter(description = "Limit the results", required = true)
            @PathVariable(value = "limit") @Min(1) Integer limit) {
        Optional<List<BookDTO>> allBooksByAuthorIdOptional = Optional.ofNullable(bookService.getBooksNotUsedOrLeastUsedByGivenWord(word, limit));
        if (allBooksByAuthorIdOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).body(allBooksByAuthorIdOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Delete all books by name of the book and author
     *
     * @param authorName Name of the author
     * @param bookName   Name of the book
     * @return Boolean
     */
    @Operation(summary = "Delete all books by name of the book and author", tags = "books")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found and Deleted the author",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid id supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "Author not found",
                    content = @Content)})
    @DeleteMapping("/authors/{authorName}/books/{bookName}")
    public ResponseEntity<Boolean> deleteAllBooksByAuthorNameAndBookName(
            @Parameter(name = "authorName", description = "Name of the author", required = true)
            @PathVariable(value = "authorName") @NotBlank(message = "Name of the author cannot be blank") String authorName,
            @Parameter(name = "bookName", description = "Name of the book", required = true)
            @PathVariable(value = "bookName") @NotBlank(message = "Name of the book cannot be blank") String bookName
    ) {
        Optional<Boolean> isAuthorDeleted = bookService.deleteAllBooksByAuthorNameAndBookName(authorName, bookName);
        return ResponseEntity.ok(isAuthorDeleted.get());
    }
}
