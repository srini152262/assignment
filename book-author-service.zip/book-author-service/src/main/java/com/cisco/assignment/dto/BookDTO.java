package com.cisco.assignment.dto;

import com.cisco.assignment.model.Book;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.modelmapper.ModelMapper;

@Getter
@Setter
public class BookDTO {

    @Schema(description = "Unique identifier of the Book.",
            example = "1", required = true)
    @JsonIgnore
    private long bookId;

    @Schema(description = "Name of the book",
            example = "Designing Rest API in Spring Boot", required = true)
    @JsonProperty(value = "bookName")
    private String bookName;

    @Schema(description = "Content of the book",
            example = "This guides you on how to develop rest api in spring boot application", required = true)
    @JsonProperty(value = "content")
    private String content;

    @Schema(description = "Author of the book",
            example = "Srinivasan Duraiswamy", required = true)
    @JsonProperty(value = "author")
    private AuthorDTO author;

    public Book convertToEntity() {
        ModelMapper mapper = new ModelMapper();
        return mapper.map(this, Book.class);
    }
}
