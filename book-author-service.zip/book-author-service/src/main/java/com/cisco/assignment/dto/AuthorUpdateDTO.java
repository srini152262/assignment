package com.cisco.assignment.dto;

import com.cisco.assignment.model.Author;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.modelmapper.ModelMapper;

import javax.validation.constraints.Min;

@Getter
@Setter
public class AuthorUpdateDTO {

    @Schema(description = "Unique identifier of the Author.",
            example = "1", required = true)
    @JsonIgnore
    private long authorId;

    @Schema(description = "Name Of The Author",
            example = "Srinivasan", required = true)
    @JsonIgnore
    private String name;

    @Schema(description = "Age Of The Author",
            example = "35", required = true)
    @JsonProperty(value = "age")
    @Min(5)
    private Integer age;

    public Author convertToEntity() {
        ModelMapper modelMapper = new ModelMapper();
        return modelMapper.map(this, Author.class);
    }
}
