package com.cisco.assignment.controller;

import com.cisco.assignment.dto.AuthorDTO;
import com.cisco.assignment.dto.AuthorRequestDTO;
import com.cisco.assignment.dto.AuthorUpdateDTO;
import com.cisco.assignment.exception.ResourceNotFoundException;
import com.cisco.assignment.service.AuthorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@Validated
@Tag(name = "authors", description = "The Authors API")
@RequestMapping(path = {"/api/v1"}, produces = APPLICATION_JSON_VALUE)
public class AuthorController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthorController.class);

    @Autowired
    private AuthorService authorService;


    /**
     * Create Author
     *
     * @param authorRequestDTO {@link AuthorRequestDTO}
     * @return AuthorDTO
     */
    @Operation(summary = "Create an author", tags = "authors")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Create the author",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid input supplied",
                    content = @Content)})
    @PostMapping("/authors")
    public ResponseEntity<AuthorDTO> createAuthor(
            @Valid @RequestBody AuthorRequestDTO authorRequestDTO) {
        Optional<AuthorDTO> authorDTOOptional = authorService.createAuthor(authorRequestDTO);
        if (authorDTOOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.CREATED).body(authorDTOOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    /**
     * Get All Authors
     *
     * @return List Of AuthorDTO
     */
    @Operation(summary = "Get list of all the authors", tags = "authors")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Return all the authors",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "404", description = "No Authors found",
                    content = @Content)})
    @GetMapping("/authors")
    public ResponseEntity<List<AuthorDTO>> getAllAuthors() {
        Optional<List<AuthorDTO>> authorDTOList = authorService.getAllAuthors();
        if (authorDTOList.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).body(authorDTOList.get());
        } else {
            throw new ResourceNotFoundException("No Authors Found");
        }
    }

    /**
     * Get Author By Name
     *
     * @param authorName Name of the author
     * @return List Of {@link AuthorDTO}
     */
    @Operation(summary = "Get authors by name", tags = "authors")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found the authors",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid name supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "No Author found",
                    content = @Content)})
    @GetMapping("/authors/{name}")
    public ResponseEntity<List<AuthorDTO>> getAuthorsByName(
            @Parameter(description = "Name of the author", required = true)
            @PathVariable(value = "name") @NotBlank(message = "Name cannot be blank") String authorName) {
        List<AuthorDTO> authorDTOList = authorService.getAuthorByName(authorName);
        if (Objects.nonNull(authorDTOList) && authorDTOList.size() > 0) {
            return ResponseEntity.status(HttpStatus.OK).body(authorDTOList);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Update author by name
     *
     * @param authorName      Name of the author
     * @param authorUpdateDTO {@link AuthorUpdateDTO}
     * @return AuthorDTO
     */
    @Operation(summary = "Update an author by name", tags = "authors")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found and Updated the author",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid id supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "Author not found",
                    content = @Content)})
    @PutMapping("/authors/{name}")
    public ResponseEntity<AuthorDTO> updateAuthorByName(
            @PathVariable(value = "name") String authorName,
            @Valid @RequestBody AuthorUpdateDTO authorUpdateDTO) {
        Optional<AuthorDTO> authorDTOOptional = authorService.updateAuthorByName(authorName, authorUpdateDTO);
        if (authorDTOOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).body(authorDTOOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    /**
     * Delete Authors By Name
     *
     * @param authorName Name of the author
     * @return Boolean
     */
    @Operation(summary = "Delete authors by name", tags = "authors")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Found and Deleted the authors",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid id supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "Authors not found",
                    content = @Content)})
    @DeleteMapping("/authors/{name}")
    public ResponseEntity<Boolean> deleteAuthorByName(
            @PathVariable(value = "name") String authorName
    ) {
        Optional<Boolean> isAuthorDeleted = authorService.deleteAuthorByName(authorName);
        return ResponseEntity.ok(isAuthorDeleted.get());
    }

    /**
     * Retrieve Top N authors who uses the given word the most
     *
     * @param word  Search Word
     * @param limit Limit of the search
     * @return List Of {@link AuthorDTO}
     */
    @Operation(summary = "Retrieve Top N authors who uses the given word the most", tags = "author")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Retrieve Top N authors who uses the given word the most",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid id supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "No Authors found who uses the given word",
                    content = @Content)})
    @GetMapping("/authors/mostused/word/{word}/limit/{limit}")
    public ResponseEntity<List<AuthorDTO>> getAuthorsWhoUsedGivenWordMost(
            @Parameter(description = "Word to search", required = true)
            @PathVariable(value = "word") @NotBlank(message = "Search word cannot be blank") String word,
            @Parameter(description = "Limit the results", required = true)
            @PathVariable(value = "limit") @Min(1) Integer limit) {
        Optional<List<AuthorDTO>> allBooksByAuthorIdOptional = Optional.ofNullable(authorService.getAuthorsWhoUsedGivenWordMost(word, limit));
        if (allBooksByAuthorIdOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).body(allBooksByAuthorIdOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    /**
     * Retrieve Top N authors who uses the given word the least or not
     *
     * @param word  Search Word
     * @param limit Limit of the search
     * @return List Of {@link AuthorDTO}
     */
    @Operation(summary = "Retrieve Top N authors who uses the given word the least or not", tags = "author")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Retrieve Top N authors who uses the given word the least or not",
                    content = {@Content(mediaType = "application/json",
                            schema = @Schema(implementation = AuthorDTO.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid id supplied",
                    content = @Content),
            @ApiResponse(responseCode = "404", description = "No Authors found who doesn't or least uses the given word",
                    content = @Content)})
    @GetMapping("/authors/leastused/word/{word}/limit/{limit}")
    public ResponseEntity<List<AuthorDTO>> getTopTenAuthorsWhoUsedGivenWordLeastOrNot(
            @Parameter(description = "Word to search", required = true)
            @PathVariable(value = "word") @NotBlank(message = "Search word cannot be blank") String word,
            @Parameter(description = "Limit the results", required = true)
            @PathVariable(value = "limit") @Min(1) Integer limit) {
        Optional<List<AuthorDTO>> allBooksByAuthorIdOptional = Optional.ofNullable(authorService.getAuthorsWhoUsedGivenWordLeastOrNot(word, limit));
        if (allBooksByAuthorIdOptional.isPresent()) {
            return ResponseEntity.status(HttpStatus.OK).body(allBooksByAuthorIdOptional.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
}
