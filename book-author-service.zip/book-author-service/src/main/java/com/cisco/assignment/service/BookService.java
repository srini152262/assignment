package com.cisco.assignment.service;

import com.cisco.assignment.dto.AuthorDTO;
import com.cisco.assignment.dto.BookDTO;
import com.cisco.assignment.dto.BookRequestDTO;
import com.cisco.assignment.exception.ResourceAlreadyFoundException;
import com.cisco.assignment.exception.ResourceNotFoundException;
import com.cisco.assignment.model.Author;
import com.cisco.assignment.model.Book;
import com.cisco.assignment.repository.AuthorRepository;
import com.cisco.assignment.repository.BookRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class BookService {
    private static final Logger LOGGER = LoggerFactory.getLogger(BookService.class);

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private AuthorRepository authorRepository;

    /**
     * Create New Book
     *
     * @param authorName     Name of the author
     * @param bookRequestDTO {@link BookRequestDTO}
     * @return BookDTO
     */
    public Optional<BookDTO> createBook(String authorName, BookRequestDTO bookRequestDTO) {
        Optional<Book> bookOptional = Optional.ofNullable(bookRepository.findByBookNameAndAuthorName(bookRequestDTO.getBookName(), authorName));
        if (bookOptional.isPresent()) {
            throw new ResourceAlreadyFoundException("Found duplicate for book " + bookRequestDTO.getBookName() + " and author " + authorName);
        }
        List<Author> authorList = authorRepository.findByNameIgnoreCase(authorName);
        if (Objects.nonNull(authorList) && authorList.size() > 0) {
            bookRequestDTO.setAuthor(authorList.get(0).convertToDTO());
            return Optional.of(bookRepository.save(bookRequestDTO.convertToEntity()).convertToDTO());
        } else {
            throw new ResourceNotFoundException("Author not found with the name " + authorName);
        }
    }


    /**
     * Update the content of the book for the given book id and author id
     *
     * @param authorName Name of the Author
     * @param bookName   Name of the Book
     * @param content    Content of the book
     * @return Optional Of {@link BookDTO}
     */
    public Optional<BookDTO> updateBookContent(String authorName, String bookName, String content) {
        Optional<Book> bookOptional = Optional.ofNullable(bookRepository.findByBookNameAndAuthorName(bookName, authorName));
        if (bookOptional.isPresent()) {
            bookOptional.get().setContent(content);
            return Optional.of(bookRepository.save(bookOptional.get()).convertToDTO());
        } else {
            throw new ResourceNotFoundException("No Book found with the name " + bookName + " and author " + authorName);
        }
    }


    /**
     * Get all books by name of the author
     *
     * @param authorName Name of the author
     * @return Optional Of {@link AuthorDTO}
     */
    public Optional<List<BookDTO>> getAllBooksByAuthorName(String authorName) {
        List<BookDTO> bookDTOList = new ArrayList<>();
        List<Author> authorList = authorRepository.findByNameIgnoreCase(authorName);
        if (Objects.nonNull(authorList) && authorList.size() > 0) {
            List<Book> bookListByAuthorId = bookRepository.findByAuthorAuthorId(authorList.get(0).getAuthorId());
            if (Objects.nonNull(bookListByAuthorId) && bookListByAuthorId.size() > 0) {
                bookListByAuthorId.stream().forEach(book -> {
                    bookDTOList.add(book.convertToDTO());
                });
                return Optional.of(bookDTOList);
            } else {
                throw new ResourceNotFoundException("No Books found for the author " + authorName);
            }
        } else {
            throw new ResourceNotFoundException("No Author found for the name " + authorName);
        }
    }

    /**
     * Retrieve Top N books in which the given word is used a lot
     *
     * @param word  Search Word
     * @param limit Limit of the search
     * @return List Of {@link BookDTO}
     */
    public List<BookDTO> getBooksWhichUsesGivenWordMost(String word, Integer limit) {
        List<BookDTO> bookDTOList = new ArrayList<>();
        Set<Book> allBooksByWordCntDesc = bookRepository.findBooksWhichUsesGivenWordMost(word, limit);
        if (Objects.nonNull(allBooksByWordCntDesc) && allBooksByWordCntDesc.size() > 0) {
            allBooksByWordCntDesc.stream().forEach(book -> {
                bookDTOList.add(book.convertToDTO());
            });
        } else {
            throw new ResourceNotFoundException("No Books found for the given word " + word);
        }
        return bookDTOList;
    }

    /**
     * Retrieve Top N books in which a given word is not used at all or used least number of times
     *
     * @param word  Search Word
     * @param limit Limit Of the Search
     * @return List Of {@link BookDTO}
     */
    public List<BookDTO> getBooksNotUsedOrLeastUsedByGivenWord(String word, Integer limit) {
        List<BookDTO> bookDTOList = new ArrayList<>();
        Set<Book> allBooksByWordCntDesc = bookRepository.findBooksNotUsedOrLeastUsedByGivenWord(word, limit);
        if (Objects.nonNull(allBooksByWordCntDesc) && allBooksByWordCntDesc.size() > 0) {
            allBooksByWordCntDesc.stream().forEach(book -> {
                bookDTOList.add(book.convertToDTO());
            });
        } else {
            throw new ResourceNotFoundException("No Books found for the given word" + word);
        }
        return bookDTOList;
    }


    /**
     * Delete book by book name and author name
     *
     * @param authorName Name of the author
     * @param bookName   Name of the book
     * @return Boolean
     */
    public Optional<Boolean> deleteAllBooksByAuthorNameAndBookName(String authorName, String bookName) {
        Optional<Book> bookOptional = Optional.ofNullable(bookRepository.findByBookNameAndAuthorName(bookName, authorName));
        if (bookOptional.isPresent()) {
            bookRepository.delete(bookOptional.get());
            return Optional.of(true);
        } else {
            throw new ResourceNotFoundException("No Book found with the name " + bookName + " and author " + authorName);
        }
    }

}
