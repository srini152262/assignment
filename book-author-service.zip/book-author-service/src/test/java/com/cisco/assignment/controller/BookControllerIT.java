package com.cisco.assignment.controller;

import com.cisco.assignment.RestServiceApplication;
import com.cisco.assignment.dto.BookDTO;
import com.cisco.assignment.dto.BookRequestDTO;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(
        classes = RestServiceApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class BookControllerIT {

    @LocalServerPort
    private int port;

    TestRestTemplate restTemplate = new TestRestTemplate();

    HttpHeaders headers = new HttpHeaders();

    private String createURLWithPort(String uri) {
        return "http://localhost:" + port + "/api/v1" + uri;
    }

    @Sql({"classpath:schema.sql", "classpath:data.sql"})
    @Test
    public void testCreateBook() {
        BookRequestDTO bookRequestDTO = new BookRequestDTO();
        bookRequestDTO.setBookName("Box Car");
        bookRequestDTO.setContent("test content");

        HttpEntity<Object> entity = new HttpEntity<Object>(bookRequestDTO, headers);

        ResponseEntity<BookDTO> response = restTemplate.exchange(
                createURLWithPort("/authors/prithivi/books"),
                HttpMethod.POST, entity, BookDTO.class);
        assertTrue(response.getStatusCode() == HttpStatus.CREATED);
    }

    @Sql({"classpath:schema.sql", "classpath:data.sql"})
    @Test
    public void testUpdateBookContent() {
        HttpEntity<Object> entity = new HttpEntity<Object>("Updating content", headers);

        ResponseEntity<BookDTO> response = restTemplate.exchange(
                createURLWithPort("/authors/srini/books/Box Car 1"),
                HttpMethod.PUT, entity, BookDTO.class);
        assertTrue(response.getStatusCode() == HttpStatus.OK);
        assertTrue(response.getBody().getContent().equals("Updating content"));
    }

    @Sql({"classpath:schema.sql", "classpath:data.sql"})
    @Test
    public void testGetTopTenBooksUseGivenWordMost() {
        HttpEntity<Object> entity = new HttpEntity<Object>(null, headers);

        ResponseEntity<List<BookDTO>> response = restTemplate.exchange(
                createURLWithPort("/books/mostused/word/writing/limit/5"),
                HttpMethod.GET, entity, new ParameterizedTypeReference<List<BookDTO>>() {
                });
        assertTrue(response.getStatusCode() == HttpStatus.OK);
        assertTrue(response.getBody().size() == 5);
    }

    @Sql({"classpath:schema.sql", "classpath:data.sql"})
    @Test
    public void testGetTopFiveBooksNotUsedOrLeastUsedByGivenWord() {
        HttpEntity<Object> entity = new HttpEntity<Object>(null, headers);

        ResponseEntity<List<BookDTO>> response = restTemplate.exchange(
                createURLWithPort("/books/mostused/word/writing/limit/5"),
                HttpMethod.GET, entity, new ParameterizedTypeReference<List<BookDTO>>() {
                });
        assertTrue(response.getStatusCode() == HttpStatus.OK);
        assertTrue(response.getBody().size() == 5);
    }

    @Sql({"classpath:schema.sql", "classpath:data.sql"})
    @Test
    public void testDeleteAllBooksByAuthorNameAndBookName() {
        HttpEntity<Object> entity = new HttpEntity<Object>(null, headers);

        ResponseEntity<Boolean> response = restTemplate.exchange(
                createURLWithPort("/authors/srini/books/Box Car 1"),
                HttpMethod.DELETE, entity, Boolean.class);
        assertTrue(response.getStatusCode() == HttpStatus.OK);
    }

}
