package com.cisco.assignment.controller;

import com.cisco.assignment.RestServiceApplication;
import com.cisco.assignment.dto.AuthorDTO;
import com.cisco.assignment.dto.AuthorRequestDTO;
import com.cisco.assignment.dto.AuthorUpdateDTO;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(
        classes = RestServiceApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public class AuthorControllerIT {

    @LocalServerPort
    private int port;

    TestRestTemplate restTemplate = new TestRestTemplate();

    HttpHeaders headers = new HttpHeaders();

    private String createURLWithPort(String uri) {
        return "http://localhost:" + port + "/api/v1/authors" + uri;
    }

    @Sql({"classpath:schema.sql", "classpath:data.sql"})
    @Test
    public void testCreateAuthor() {
        AuthorRequestDTO authorRequestDTO = new AuthorRequestDTO();
        authorRequestDTO.setName("Prithivi");
        authorRequestDTO.setAge(30);
        HttpEntity<Object> entity = new HttpEntity<Object>(authorRequestDTO, headers);

        ResponseEntity<AuthorDTO> response = restTemplate.exchange(
                createURLWithPort(""),
                HttpMethod.POST, entity, AuthorDTO.class);
        assertTrue(response.getStatusCode() == HttpStatus.CREATED);
        assertTrue(response.getBody().getName().equals("Prithivi"));
    }

    @Sql({"classpath:schema.sql", "classpath:data.sql"})
    @Test
    public void testGetAllAuthors() {
        HttpEntity<String> entity = new HttpEntity<String>(null, headers);
        ResponseEntity<List<AuthorDTO>> response = restTemplate.exchange(
                createURLWithPort(""),
                HttpMethod.GET, entity, new ParameterizedTypeReference<List<AuthorDTO>>() {
                });
        assertTrue(response.getStatusCode() == HttpStatus.OK);
        assertTrue(response.getBody().size() == 3);
    }

    @Sql({"classpath:schema.sql", "classpath:data.sql"})
    @Test
    public void testGetAuthorByName() {
        HttpEntity<String> entity = new HttpEntity<String>(null, headers);
        ResponseEntity<List<AuthorDTO>> response = restTemplate.exchange(
                createURLWithPort("/srini"),
                HttpMethod.GET, entity, new ParameterizedTypeReference<List<AuthorDTO>>() {
                });
        assertTrue(response.getStatusCode() == HttpStatus.OK);
        assertTrue(response.getBody().get(0).getName().equals("srini"));
    }


    @Sql({"classpath:schema.sql", "classpath:data.sql"})
    @Test
    public void testUpdateAuthorByName() {
        AuthorUpdateDTO authorUpdateDTO = new AuthorUpdateDTO();
        authorUpdateDTO.setAge(27);
        HttpEntity<Object> entity = new HttpEntity<Object>(authorUpdateDTO, headers);

        ResponseEntity<AuthorDTO> response = restTemplate.exchange(
                createURLWithPort("/meera"),
                HttpMethod.PUT, entity, AuthorDTO.class);
        assertTrue(response.getStatusCode() == HttpStatus.OK);
        assertTrue(response.getBody().getAge().equals(27));
    }

    @Sql({"classpath:schema.sql", "classpath:data.sql"})
    @Test
    public void testDeleteAuthorByName() {
        HttpEntity<Object> entity = new HttpEntity<Object>(null, headers);
        ResponseEntity<Boolean> response = restTemplate.exchange(
                createURLWithPort("/prithivi"),
                HttpMethod.DELETE, entity, Boolean.class);
        assertTrue(response.getStatusCode() == HttpStatus.OK);
        assertTrue(response.getBody().equals(true));
    }

    @Test
    public void testGetTopTenAuthorsWhoUsedGivenWordMost() {
        HttpEntity<String> entity = new HttpEntity<String>(null, headers);
        ResponseEntity<List<AuthorDTO>> response = restTemplate.exchange(
                createURLWithPort("/mostused/word/writing/limit/10"),
                HttpMethod.GET, entity, new ParameterizedTypeReference<List<AuthorDTO>>() {
                });
        assertTrue(response.getStatusCode() == HttpStatus.OK);
        assertTrue(response.getBody().size() == 2);
    }

    @Test
    public void testGetTopTenAuthorsWhoUsedGivenWordLeastOrNot() {
        HttpEntity<String> entity = new HttpEntity<String>(null, headers);
        ResponseEntity<List<AuthorDTO>> response = restTemplate.exchange(
                createURLWithPort("/leastused/word/writing/limit/10"),
                HttpMethod.GET, entity, new ParameterizedTypeReference<List<AuthorDTO>>() {
                });
        assertTrue(response.getStatusCode() == HttpStatus.OK);
        assertTrue(response.getBody().size() == 2);
    }
}
